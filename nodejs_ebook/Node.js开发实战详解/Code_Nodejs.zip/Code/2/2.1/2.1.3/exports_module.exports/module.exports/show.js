msgArr = require("./name.js");
console.log(msgArr.join(" "));
