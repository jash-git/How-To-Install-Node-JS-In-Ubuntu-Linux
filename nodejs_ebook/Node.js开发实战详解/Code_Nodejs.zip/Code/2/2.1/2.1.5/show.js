var Person = require('./module');

console.log(Person.name);

Person.init('Node.js');

Person.show();

console.log(Person.myName);
