/* component.js */
module.exports = function(){
	this.operation = function(){
		console.log('Component::operation');
	}
}