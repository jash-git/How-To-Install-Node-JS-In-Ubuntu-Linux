/**
 *
 * @type  array
 */
exports.arr = ['danhuang', 'jimi', 'teley'];