setTimeout(function(){
	console.log('wait for 5 seconds over');
}, 5000)
console.log('if it is waiting more than 5 seconds, this is a block code');