exports.name = 'danhuang';
exports.say  = function(){
	console.log('test');
}
/**
exports.show  = function(){
	console.log('hi');
}
*/